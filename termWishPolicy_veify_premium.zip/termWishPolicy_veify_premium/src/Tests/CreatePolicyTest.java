package Tests;

import lib.Data;
import lib.BaseClass;
import lib.CommonClass;
import lib.CommonExcel;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.testng.annotations.Test;

import Pages.CreateUploadFile;
import Pages.BasePage;
import Pages.ViewQuotes;

public class CreatePolicyTest extends BaseClass {

	public static Logger log = LogManager.getLogger(CreatePolicyTest.class);

	@Test(priority = 1, dataProvider = "getdata1", dataProviderClass = CommonExcel.class)
	public void fnHomePage(final int iTestCaseID, Data testData) throws Exception {
		
//		if (BasePage.HomePage.equalsIgnoreCase("Yes")) {
//			CommonClass.logger = CommonClass.extent.createTest("Wish Policy");
			boolean bTest = false;
			try {
				log.info("Start Test:" + iTestCaseID);
				log.debug("Test Data:" + testData);

				ViewQuotes hp = new ViewQuotes();
//				hp.fnViewQuotes(iTestCaseID, testData);

				Pages.CreatePolicy page = new Pages.CreatePolicy();
				CreateUploadFile.fnCleanFile();
				CommonExcel.getData2();
				
				for(int iLoginID=0; iLoginID <Data.sMemberId.size();iLoginID++) {
					try {
						
						if(testData.sLoginID.equalsIgnoreCase(Data.sMemberId.get(iLoginID))) {
//							if(bTest)
							CommonClass.logger = CommonClass.extent.createTest("Wish Policy: " +Data.sPolicy_ID.get(iLoginID));
//							    bTest=true;
							System.out.println("::::::Policy_ID == "+Data. sPolicy_ID.get(iLoginID)+":::::::::::::");
							hp.fnViewQuotes(iTestCaseID, testData);
							
							page.fnGenderSelect(iLoginID);
							page.fnAgeSelect(iLoginID);
							page.fnSmoker(iLoginID);
							page.fnPolicyCompany(iLoginID);
							page.fnMemInfo(iLoginID);
							page.fnPolicyInstallment(iLoginID);
							page.fnPlanCalculatoor(iLoginID);
							page.fnCreateCSV(iLoginID);

						}
					} catch (Exception e) {
						getStackTrace(e);
					}
				}
			} catch (Exception e) {
				log.error("------************************************------");
				log.error("@@@@@Failed Test:" + iTestCaseID);
				log.error(getStackTrace(e));
				log.error("------********Data Start******************------");
				log.error("Test Data:" + testData);
				log.error("------********Data End********************------");

				vTakeImage("Error.TCID-" + iTestCaseID);

				throw e;
			}
			log.info("@@@@@End Test:" + iTestCaseID);
		}
//	}
}
