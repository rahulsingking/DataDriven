package Pages;

import java.util.List;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import lib.Data;
import lib.Report;

public class CreatePolicy extends BasePage {

	public static Logger log = LogManager.getLogger(CreatePolicy.class);

	public CreatePolicy() {
		super();
	}
//	@FindBy(xpath = "(//span[contains(text(),'MALE')])[1]")
	@FindBy(xpath = "//div[@class='user-img'][1]")
	WebElement weGenderMale;
	@FindBy(xpath = "//span[contains(text(),'FEMALE')]")
	WebElement weGenderFemale;
	@FindBy(xpath = "(//li[@class='agesAll'])[1]")
	WebElement weAge;
	@FindBy(xpath = "(//li[@class='mb-1'])[3]")
	WebElement weSmokerNo;
	@FindBy(xpath = "(//li[@class='mb-1'])[4]")
	WebElement weSmokerYes;
	@FindBy(xpath = "//span[contains(text(),' Aegon iTerm ')]")
	WebElement weAgon;
	@FindBy(xpath = "//img[@src='assets/images/1.png']")
	WebElement weAviva;
	@FindBy(xpath = "//img[@src='assets/images/2.png']")
	WebElement weMaxLife;
	@FindBy(xpath = "//img[@src='assets/images/3.png']")
	WebElement weHDFC;
	@FindBy(xpath = "//span[contains(text(),' Canara iSelect Term Plan ')]")
	WebElement weCanara;
	@FindBy(xpath = "//span[contains(text(),' Kotak e-Term Plan Life Option ')]")
	WebElement weKotak;
	@FindBy(xpath = "//input[@name='name']")
	WebElement weName;
	@FindBy(xpath = "//input[@name='mobile']")
	WebElement weMobile;
	@FindBy(xpath = "//input[@name='email']")
	WebElement weEmail;
	@FindBy(xpath = "//div[@class='form-group mb-0']/child::input")
	WebElement weContinue;
	@FindBy(xpath = "(//button[@class='close'])[2]")
	WebElement wePopupCloseButton;
	@FindBy(xpath = "(//a[@class='btn-sm btn'])[1]")
	WebElement weContinue1;
	@FindBy(xpath = "(//a[@class='btn-sm btn'])[2]")
	WebElement weContinue2;
	@FindBy(xpath = "//div[@class='amount']")
	WebElement wePolicyAmount;
	@FindBy(xpath = "(//button[@class='dropdown-toggle'])[1]")
	WebElement weFPI1;
	@FindBy(xpath = "(//button[@class='dropdown-toggle'])[2]")
	WebElement weFPI2;
	@FindBy(xpath = "(//span[@class='icon-unavailable'])[14]")
	WebElement weClosePopup;
	@FindBy(xpath = "(//a[@class='continue btn btn-sm'])[1]")
	WebElement wePlanCont1;
	@FindBy(xpath = "(//a[@class='continue btn btn-sm'])[2]")
	WebElement wePlanCont2;
	@FindBy(xpath = "//div[@class='dropdown-menu d-block']//a[contains(text(),'Single')]")
	WebElement weSingle;
	@FindBy(xpath = "//div[@class='dropdown-menu d-block']//a[contains(text(),'Monthly')]")
	WebElement weMonthly;
	@FindBy(xpath = "//div[@class='dropdown-menu d-block']//a[contains(text(),'Quarterly')]")
	WebElement weQuarterly;
	@FindBy(xpath = "//div[@class='dropdown-menu d-block']//a[contains(text(),'Half yearly')]")
	WebElement weHalfYearly;
	@FindBy(xpath = "//div[@class='dropdown-menu d-block']//a[contains(text(),'Yearly')]")
	WebElement weYearly;
	@FindBy(xpath = "//li[contains(text(),' lakhs')]")
	List<WebElement> weLakhs;
	@FindBy(xpath = "//li[contains(text(),' crore')]")
	List<WebElement> weCrore;
	@FindBy(xpath = "//type-premium[@textval='years']")
	List<WebElement> wePolicyTerm;
	@FindBy(xpath = "//a[@class='first']")
	WebElement weBackToPolicy;

	public void fnGenderSelect(int iRow) throws Exception {
		try {
			BasePage.sTestStep = "Select Page";
			if (Data.sGender.get(iRow).equalsIgnoreCase("Female")) {
				clickElement(weGenderFemale, "SelectGender:: Female");
			} else if (Data.sGender.get(iRow).equalsIgnoreCase("Male")) {
				clickElement(weGenderMale, "SelectGender:: Male");
			}
		} catch (Exception e) {
			Report.TestReport("Wish Gender Select", "WIsh Gender Select Fail for ", Data.sPolicy_ID.get(iRow), "Fail");
			System.out.println(getStackTrace(e));
			throw e;
		}
	}
	public void fnAgeSelect(int iRow) throws Exception {
		try {
			waitForThread(500);
			BasePage.sTestStep = "Select Age";
			String sAge = String.valueOf((Integer.parseInt(Data.sAge.get(iRow)) - 17));
			System.out.println("sAge:::"+sAge);
//			WebElement weAge2 = driver.findElement(By.xpath("(//li[@class='agesAll'])[" + sAge + "]"));
			WebElement weAge2 = driver.findElement(By.xpath("(//ul[@class='numbers text-center ']/child::li)[" + sAge + "]"));
			System.out.println("weAge:::"+weAge2);
			clickElement(weAge2, "Select Age" + Data.sAge.get(iRow));
		} catch (Exception e) {
			Report.TestReport("Wish Age Select", "WIsh application Member Info Fail for ", Data.sPolicy_ID.get(iRow),
					"Fail");
			System.out.println(getStackTrace(e));
			throw e;
		}
	}
	public void fnSmoker(int iRow) throws Exception {
		try {
			BasePage.sTestStep = "Smoker";
			if (Data.sSmoker.get(iRow).equalsIgnoreCase("Yes")) {
				clickElement(weSmokerYes, "SelectSmsoker:: Yes");
			} else if (Data.sSmoker.get(iRow).equalsIgnoreCase("No")) {
				clickElement(weSmokerNo, "SelectSmsoker:: No");
			}
		} catch (Exception e) {
			Report.TestReport("Wish Smoker", "WIsh application Member Info Fail for ", Data.sPolicy_ID.get(iRow),
					"Fail");
			System.out.println(getStackTrace(e));
			throw e;
		}
	}

	public void fnPolicyCompany(int iRow) throws Exception {
		try {
			BasePage.sTestStep = "Policy Company";
			waitForThread(500);
			if (Data.sPolicyCompany.get(iRow).equalsIgnoreCase("Aegon")) {
				clickElement(weAgon, "Policy Company::Aegon");
			} else if (Data.sPolicyCompany.get(iRow).equalsIgnoreCase("Aviva")) {
				clickElement(weAviva, "Policy Company::Aegon");

			} else if (Data.sPolicyCompany.get(iRow).equalsIgnoreCase("Max")) {
				clickElement(weMaxLife, "Policy Company::Max Life ");

			} else if (Data.sPolicyCompany.get(iRow).equalsIgnoreCase("HDFC")) {
				clickElement(weHDFC, "Policy Company::HDFC Life ");
			}
			else if (Data.sPolicyCompany.get(iRow).equalsIgnoreCase("Kotak")) {
				clickElement(weKotak, "Policy Company::Kotak Life ");
			}
			else if (Data.sPolicyCompany.get(iRow).equalsIgnoreCase("Canara")) {
				clickElement(weCanara, "Policy Company::Canara HSBC ");
			}
			Report.fnExtentDebugger(true);
		} catch (Exception e) {
			System.out.println(getStackTrace(e));
			Report.TestReport("Wish PolicyCompany", "WIsh Policy Cpmpany Info Fail for ", Data.sPolicy_ID.get(iRow),
					"Fail");
			throw e;
		}
	}

	public void fnMemInfo(int iRow) throws Exception {
		try {
			BasePage.sTestStep = "Member Info";
			sendValue(weName, Data.sMemName.get(iRow), "Name Field");
			waitForThread(500);
			sendValue(weMobile, Data.sMemPhone.get(iRow), "Mobile number");
			waitForThread(500);
			sendValue(weEmail, Data.sMemEmail.get(iRow), "Email Address");
			waitForThread(1500);
			try {
				clickElement(weContinue, "Continue Button of Info Submit"); // member info popup continue
				waitForThread(500);
//				vTakeImage("Member Info Check");
//				CommonClass.logger.addScreenCaptureFromPath(BaseClass.extentImage());
//				clickElement(weContinue1, "Continue Button to Select Plan"); // 2nd COntinue button
			} catch (Exception e) {
			}
			try {
				waitForThread(500);
				System.out.println("try with Cont1::");
				clickElement(weContinue1, "Continue Button to Select Plan");
			} catch (Exception e) {
				System.out.println("Catch with Cont2::");
				clickElement(weContinue2, "Continue Button to Select Plan");
			}
		} catch (Exception e) {
			Report.TestReport("Wish MemberInfo", "WIsh application Member Info Fail for ", Data.sPolicy_ID.get(iRow),
					"Fail");
			System.out.println(getStackTrace(e));
			throw e;
		}
	}
	public void fnPolicyInstallment(int iRow) throws Exception {
		try {
			BasePage.sTestStep = "Policy Installment";
			waitForThread(1500);
			clickElement(weFPI1, "Select Policy Installment ");
			if (Data.sPolicyInstallment.get(iRow).equalsIgnoreCase("Single")) {
				clickElement(weSingle, "Policy Installment::Single");
			} else if (Data.sPolicyInstallment.get(iRow).equalsIgnoreCase("Monthly")) {
				clickElement(weMonthly, "Policy Installment::Monthly");
			} else if (Data.sPolicyInstallment.get(iRow).equalsIgnoreCase("Half Yearly")) {
				clickElement(weHalfYearly, "Policy Installment::Half Yearly");
			} else if (Data.sPolicyInstallment.get(iRow).equalsIgnoreCase("Yearly")) {
				clickElement(weYearly, "Policy Installment::Yearly");
			} else if (Data.sPolicyInstallment.get(iRow).equalsIgnoreCase("Quarterly")) {
				clickElement(weQuarterly, "Policy Installment::Quarterly");
			}

		} catch (Exception e) {
			Report.TestReport("Wish PolicyInstallment", "WIsh Policy Installment Fail for ", Data.sPolicy_ID.get(iRow),
					"Fail");
			System.out.println(getStackTrace(e));
			throw e;
		}
	}
	public void fnPlanCalculatoor(int iRow) throws Exception {
		try {
			BasePage.sTestStep = "Policy Amount Page";
			String amount = Data.sSumInsuredAmount.get(iRow);
			try {
				WebElement wePlan = driver.findElement(By.xpath("(//li[contains(text(),'" + amount + "')])[1]"));
				clickElement(wePlan, "Select Plan Amount:::"+Data.sSumInsuredAmount.get(iRow));
				String years = Data.SPolicyTerm.get(iRow);
				System.out.println(":::Term Years==::" + years);
				waitForThread(2000);
				WebElement weYear = driver.findElement(By.xpath("//li[contains(text(),'" + years + "')][span[contains(text(),'years')]]"));
				clickElement(weYear, "Select Term Year:::"+Data.SPolicyTerm.get(iRow));
			} catch (Exception e) {
				String years = Data.SPolicyTerm.get(iRow);
				System.out.println(":::##Catch Term Years==::" + years);
				waitForThread(2000);
				WebElement weYear = driver.findElement(By.xpath("//li[contains(text(),'" + years + "')][span[contains(text(),'years')]]"));
				clickElement(weYear, "Select Term Year:::"+Data.SPolicyTerm.get(iRow));
			}
		} catch (Exception e) {
			Report.TestReport("Wish PlanCalculator", "WIsh application Plan Calculator Fail for ",
					Data.sPolicy_ID.get(iRow), "Fail");
			System.out.println(getStackTrace(e));
			throw e;
		}
	}
	public void fnCreateCSV(int iRow) throws Exception {
		try {
			String pamt = "";
			try {
				waitForThread(2000);
				WebElement wePremium = driver
						.findElement(By.xpath("//li[a[span[text()='to policy settings']]]/following-sibling::li/a"));
				pamt = wePremium.getText();
				System.out.println("Premium::" + pamt);
				pamt = pamt.replaceAll("[^0-9]", "");
			} catch (Exception e) {
			}
			CreateUploadFile.fnUpdateCSV(Data.sPolicy_ID.get(iRow), true);
			CreateUploadFile.fnUpdateCSV(Data.sAge.get(iRow), false);
			CreateUploadFile.fnUpdateCSV(Data.sGender.get(iRow), false);
			CreateUploadFile.fnUpdateCSV(Data.sSmoker.get(iRow), false);
			CreateUploadFile.fnUpdateCSV(Data.sPolicyCompany.get(iRow), false);
			CreateUploadFile.fnUpdateCSV(Data.sPolicyInstallment.get(iRow), false);
			CreateUploadFile.fnUpdateCSV(Data.sSumInsuredAmount.get(iRow), false);
			CreateUploadFile.fnUpdateCSV(Data.SPolicyTerm.get(iRow), false);
			CreateUploadFile.fnUpdateCSV(Data.sExpPremAmt.get(iRow), false);
			CreateUploadFile.fnUpdateCSV(pamt, false);
			if (Data.sExpPremAmt.get(iRow).equalsIgnoreCase(pamt)) {
				CreateUploadFile.fnUpdateCSV("Pass", false);
			}
			else {
				CreateUploadFile.fnUpdateCSV("Fail", false);
			}
			try {
				int e_premium=Integer.parseInt(Data.sExpPremAmt.get(iRow));
				String d_premium = String.valueOf(Integer.parseInt(pamt)-e_premium);
				System.out.println("Difference of Premium ::::"+d_premium);
				CreateUploadFile.fnUpdateCSV(d_premium, false);
			} catch (Exception e) {
				System.out.println("Policy Premium diff is not applicale for this test");
			}
			Report.TestReport("Wish Policy", "Policy is pass for", Data.sPolicy_ID.get(iRow), "Pass");
			
		} catch (Exception e) {
			Report.TestReport("Wish Premium", "Premium is fail for", Data.sPolicy_ID.get(iRow), "Fail");
			throw e;
		}
	}
	public void fnRider(int iRow) throws Exception {
		try {
			BasePage.sTestStep = "Rider Page";
			if (weBackToPolicy.getText().equalsIgnoreCase("Back to policy settings")) {
				Report.fnExtentDebugger(true);
				Report.TestReport("Wish Rider Verification", "WIsh application Rider  Pass for ", "Policy Validation",
						"Pass");
			} else {
				System.out.println("Policy Unsuccessfull");
				Report.TestReport("Wish Rider Verification", "WIsh application Rider  Fail for ", "Policy Validation",
						"Fail");
			}
		} catch (Exception e) {

			Report.TestReport("Wish Rider", "WIsh application Rider Info Fail for ", Data.sPolicy_ID.get(iRow), "Fail");
			System.out.println(getStackTrace(e));
			throw e;
		}
	}
}