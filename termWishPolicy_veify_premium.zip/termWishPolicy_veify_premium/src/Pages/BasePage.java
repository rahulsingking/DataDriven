package Pages;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import lib.BaseClass;
import lib.CommonClass;

public class BasePage extends BaseClass
{
	public static Logger log = LogManager.getLogger(BasePage.class);
	public static String sFailMsg = null;
	public static String sTestStep = null;
	public static List<String> sApplication = new ArrayList<String>();
	public static String sPopupImg1="Data\\wp1.PNG";
	public static int iWaitPage=0;
//	public static String HomePage=null;

	public static String Wish_URL=null;
	public static String sDataPath=null;
	public static String IEDriver_Path=null;
	public static String EmailSendto=null;
	public static String EmailCC1=null;
	public static String EmailCC2=null;
	
	public static String sPopupImg=null;
	public static WebElement we = null;
	
	public String LoginID;
	public BasePage()
	{
		DOMConfigurator.configure("log4j.xml");
		PageFactory.initElements(CommonClass.driver, this);
	}

	public static void fnConfig() {
		InputStream input=null;
		Properties prop = new Properties();
		try {
			String filename = "Data\\config.properties";
			input = new FileInputStream(filename);
			prop.load(input);

			Wish_URL=prop.getProperty("Wish_URL").trim();
			sDataPath=prop.getProperty("DataPath").trim();
			EmailSendto=prop.getProperty("Email_Sendto").trim();
			EmailCC1=prop.getProperty("Email_CC1").trim();
			EmailCC2=prop.getProperty("Email_CC2").trim();
			

		} catch (IOException ex) {
			ex.printStackTrace();
		} finally{
			if(input!=null){
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
