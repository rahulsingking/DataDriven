package Pages;

import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import lib.CommonClass;
import lib.Data;
import lib.Report;

public class ViewQuotes extends BasePage {

	public static Logger Log = LogManager.getLogger(ViewQuotes.class);

	public ViewQuotes() {
		super();
	}

	@FindBy(xpath = "//button[@class='btn d-none d-md-inline-block ']")
	WebElement weViewQuotes;

	@FindBy(xpath = "(//button[@type='button'])[4]")
	WebElement weGenderMale;

	@FindBy(xpath = "(//button[@type='button'])[5]")
	WebElement weGenderFemale;

	@FindBy(xpath = "//li[@class='agesAll']")
	List<WebElement> weAge;
	
	@FindBy(xpath = "//li[@class='agesAll']")
	WebElement weAge1;
	
	@FindBy(xpath = "(//button[@type='button'])[73]")
	WebElement weSmokerYes;
	
	@FindBy(xpath = "(//button[@type='button'])[74]")
	WebElement weSmokerNo;
	
	@FindBy(xpath = "//li[@class='agesAll']")
	WebElement wenew ;
	
	public void fnViewQuotes(final int iTestCaseID, Data testData) throws Exception {
		try {
			fnWaitPage(iWaitPage);
			BasePage.sTestStep="HomePage";
			System.out.println("::::Base URL :::::::");
			isAlertPresent();
			CommonClass.driver.get(CommonClass.sBaseURL);
			System.out.println("Url Launched successfully::url::"+sBaseURL);
			clickElement(weViewQuotes, "Click on View Button");

		} catch (Exception e) {
			System.out.println(getStackTrace(e));
			Report.TestReport("Wish Login", "WIsh application login Fail for ", "", "Fail");
			throw e;
		}
	}
}
