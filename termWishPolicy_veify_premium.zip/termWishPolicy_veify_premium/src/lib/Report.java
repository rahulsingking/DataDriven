package lib;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.activation.CommandMap;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.activation.MailcapCommandMap;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import Pages.BasePage;
import Pages.MailProp.EmailSessionProperty;


public class Report extends BaseClass {

	public static FileOutputStream fos;
	public static BufferedWriter bw;
	public static Logger log = LogManager.getLogger(Report.class);
	public static String sFailMsg;

	public static void fnModResult() throws Exception {
		File fout = new File("Result\\CustomReport.csv");
		fos = new FileOutputStream(fout, true);
		bw = new BufferedWriter(new OutputStreamWriter(fos));
	}

	public static void fnCustomReport(String str, boolean bLine) throws Exception {
		try{
			fnModResult();
			if(bLine)
				bw.newLine();
			bw.write(str);
			bw.write(", ");
		}
		catch(Exception e){
			log.error("Unable to update Test result in file.");
		}
		finally{
			if(bw!=null)
				bw.close();
		}
	}

	public static String fnDate() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		return dtf.format(now);
	}

	public static void TestReport(String sTestName, String sLabel, String sApplication, String sResult) throws Exception {
		if(sResult.equalsIgnoreCase("Pass")){
			CommonClass.logger.log(Status.PASS, MarkupHelper.createLabel(sLabel+" Policy ID is :[["+sApplication+" ]]", 
					ExtentColor.INDIGO));
			CommonClass.logger.addScreenCaptureFromPath(BaseClass.extentImage());
			Report.fnCustomReport(Report.fnDate(), true);
			Report.fnCustomReport(sTestName, false);
			Report.fnCustomReport(sLabel, false);
			Report.fnCustomReport(sApplication, false);
			Report.fnCustomReport("Pass", false);

		}
		else if(sResult.equalsIgnoreCase("Fail")){
			CommonClass.logger.log(Status.FAIL, MarkupHelper.createLabel(sLabel+" Policy ID is :[["+sApplication+" ]]", 
					ExtentColor.RED));
			CommonClass.logger.addScreenCaptureFromPath(BaseClass.extentImage());
			Report.fnCustomReport(Report.fnDate(), true);
			Report.fnCustomReport(sTestName, false);
			Report.fnCustomReport(sLabel, false);
			Report.fnCustomReport(sApplication, false);
			Report.fnCustomReport("Fail", false);
			Report.fnCustomReport("Test fail at step :[["+BasePage.sTestStep+" ]] and fail msg is [["+BasePage.sFailMsg+"]]",false);
		}
	}
	
	public static void fnExtentDebugger(boolean sFlag) {
		fnExtentDebugger(sFlag, "");
	}

	public static void fnExtentDebugger(boolean sFlag, String sMsg) {
		if(sFlag)
			CommonClass.logger.debug("<font color='white' style='background:#4CAF50; padding:3px 6px; border-radius: 4px;"
					+"font-weight: 600;font-size:  90%;'>"+"Test passed till the step :[[ "+BasePage.sTestStep+" ]]"
					+"</font>");
		if(!sFlag)
			CommonClass.logger.debug("<font color='white' style='background:#F7464A; padding:3px 6px; border-radius: 4px;"
					+"font-weight: 600;font-size:  90%;'>"+"Test "+ sMsg+" fail at step :"+BasePage.sTestStep+" [[ "
					+BasePage.sFailMsg+" ]]"+"</font>");
	}

	public static void getFailText(WebElement weMsg, String sfailMsg) {
		try {
			BasePage.sFailMsg = weMsg.getText();
			if(BasePage.sFailMsg!=null)
				BasePage.sFailMsg = sfailMsg;
		}
		catch (Exception e) {
			BasePage.sFailMsg = sfailMsg;
		}

	}
	public static String attachedMail(String cc,String cc1,String from,String senderName,String to,String mailBody,String mailSubject,String filePath,String fileName){
        try {
            long start = System.currentTimeMillis();
            Session session = EmailSessionProperty.getEmailPropertySession();
            Message message = new MimeMessage(session);
            MailcapCommandMap mc = (MailcapCommandMap) CommandMap.getDefaultCommandMap(); 
            mc.addMailcap("text/html;; x-java-content-handler=com.sun.mail.handlers.text_html"); 
            mc.addMailcap("text/xml;; x-java-content-handler=com.sun.mail.handlers.text_xml"); 
            mc.addMailcap("text/plain;; x-java-content-handler=com.sun.mail.handlers.text_plain"); 
            mc.addMailcap("multipart/*;; x-java-content-handler=com.sun.mail.handlers.multipart_mixed"); 
            mc.addMailcap("message/rfc822;; x-java-content- handler=com.sun.mail.handlers.message_rfc822");
            message.setContent(mailBody, "UTF-8");
            if (!(cc == null || cc.trim().isEmpty())) {
                message.addRecipients(Message.RecipientType.CC, InternetAddress.parse(cc));
            }
            if (!(cc == null || cc1.trim().isEmpty())) {
                message.addRecipients(Message.RecipientType.CC, InternetAddress.parse(cc1));
            }
            message.setFrom(new InternetAddress(from, senderName));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
            message.setSubject(mailSubject);
            message.setHeader("X-MC-Tags", "non-mandotary");
            BodyPart messageBodyPart = new MimeBodyPart();
            Multipart multipart = new MimeMultipart();
            if(filePath==null || filePath.trim().isEmpty())
                throw  new RuntimeException("Server Path not found");
            DataSource source = new FileDataSource(filePath);
            messageBodyPart.setDataHandler(new DataHandler(source));
            if(fileName==null || fileName.trim().isEmpty())
                throw  new RuntimeException("File Name not found");
            if (fileName.contains("/")){
                String arr[]=fileName.split("/");
                fileName=arr[(arr.length-1)];
            }
            messageBodyPart.setFileName(fileName);
            multipart.addBodyPart(messageBodyPart);
            message.setContent(multipart);
            Transport.send(message);
            long end = System.currentTimeMillis();
            logger.info("Time taken:- " + ((end - start) / 1000) + " sec");
            return "Success";
        } catch (MessagingException | UnsupportedEncodingException e) {
           System.out.println(getStackTrace(e));
            return "Failure";
        } catch (Exception e){
            return "Failure";
        }
    }
	
}
