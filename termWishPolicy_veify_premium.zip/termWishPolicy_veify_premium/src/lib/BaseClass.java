package lib;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.AssertJUnit;

import Pages.BasePage;


public class BaseClass extends CommonClass
{
	public static Logger log = LogManager.getLogger(BaseClass.class);
	// To Check all the validation messages - Print/Capture Screenshot
	public boolean myAssertEquals (String str1, String str2, String strMsg) throws Exception
	{
		try
		{
			AssertJUnit.assertEquals (str1, str2);
			log.debug(getClassFuncName(3)+"Verified: " + strMsg);
			CommonClass.logger.debug("Verified: "+strMsg);
			return true;
		}
		catch (Error e)
		{
			CommonClass.logger.debug("Not verified: "+strMsg);
			throw e;
		}
	}

	// To check Fields present or not - Print/Capture Screenshot
	public boolean myAssertTrue (boolean condition, String strMsg) throws Exception
	{
		try
		{
			AssertJUnit.assertTrue (condition);
			log.debug(getClassFuncName(3)+"Verified: " + strMsg);
			return true;
		}
		catch (Error e)
		{
			CommonClass.logger.debug("Element not found: "+strMsg);
			throw e;
		}
	}

	public boolean myWaitNAssertTrue(WebElement weElement, String strMsg) throws Exception
	{
		waitElement(weElement);
		return myAssertTrue(weElement.isDisplayed(), strMsg);
	}

	public static boolean isAlertPresent()
	{
		try{
			CommonClass.driver.switchTo().alert();
			return true;
		}
		catch (Exception e){
			return false;
		}
	}

	public void waitForThread(int wait) throws InterruptedException 
	{
		Thread.sleep(wait);
	}

	public void vTakeImage() throws Exception
	{
		vTakeImage("");
	}

	public void vTakeImage(String strMsg) throws Exception
	{
		vTakeImage(strMsg, false, 4);
	}

	public void vTakeImage(String strMsg, boolean bIsError, int iLevel ) throws Exception
	{
		int iImgCounter = CommonClass.getNextImgCounter();

		String sFileName = CommonClass.IMAGES_PATH + iImgCounter + (bIsError?".Err":"") + "." + strMsg + ".png";
		try
		{
			log.debug(getClassFuncName(iLevel)+":Taking screenshot("+iImgCounter+"): " + strMsg + " :" + sFileName);

			File scrFile = ((TakesScreenshot) CommonClass.driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File(sFileName));
			log.debug(getClassFuncName(iLevel)+":Taken screenshot("+iImgCounter+"): " + sFileName);
		}
		catch(Exception e1)
		{
			log.error(getClassFuncName(iLevel)+"Unable to take screenshot[" + sFileName + "]:" + strMsg + ":" + e1.toString());
			//			log.error(getStackTrace(e1));
		}
	}

	public static String extentImage() throws Exception
	{
		try {
		int iImgCounter = CommonClass.getNextImgCounter();

		String sFileName = (System.getProperty("user.dir")+"/Result/"+ iImgCounter +".png");
		File scrFile = ((TakesScreenshot) CommonClass.driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrFile, new File(sFileName));
		return sFileName;
		}catch (Exception e) {
			System.out.println(getStackTrace(e));
			return null;
		}
	}

	public String GetBrowserName()
	{
		Capabilities cap = ((RemoteWebDriver) CommonClass.driver).getCapabilities();
		String browserName = cap.getBrowserName().toLowerCase();
		log.debug(getClassFuncName(3)+"Browser Name is: "+browserName);
		return browserName;
	}

	public void ClickAndTakeImage(String sMessage, WebElement weElement) throws Exception
	{
		ClickAndTakeImage(sMessage, weElement, 500, 5);
	}

	public void ClickAndTakeImage(String sMessage, WebElement weElement, int iWaitForThread, int iLevel) throws Exception
	{
		long tmStart, tmEnd;
		try {
			log.debug(getClassFuncName(iLevel)+"Before clicking " + sMessage);
			vTakeImage("Before clicking " + sMessage, false, 4);
			waitForThread(700);
			tmStart = System.nanoTime();	
			clickElement(weElement, sMessage);
			// Report 	
			Report.fnExtentDebugger(true);

			tmEnd= System.nanoTime();
			waitForThread(700);

			if(iWaitForThread > 0)
			{
				waitForThread(iWaitForThread);
			}
			log.debug(getClassFuncName(iLevel)+"Time waited for " + sMessage + " :" + ((tmEnd-tmStart)/(1000*1000)) + " msecs");
			vTakeImage("After clicking " + sMessage, false, 4);
		}
		catch (Exception e) {
			Report.fnExtentDebugger(false);
		}
	}

	public void clickElement(WebElement weElement) throws Exception
	{
		clickElement(weElement, "");
	}

	
	public void clickElement(WebElement weElement, String msg) throws Exception
	{
		try{
			boolean bRetry;
			for(int i=0; i< 20; i++){
				bRetry = false;
				try{
					if(weElement.isEnabled())
						weElement.click();
					if(isAlertPresent()){
						try{
							BasePage.sFailMsg= CommonClass.driver.switchTo().alert().getText();
							CommonClass.driver.switchTo().alert().accept();
						}
						catch(Exception e){getStackTrace(e);}
						finally{
							if(!bRetry)
								return;
						}}
					log.debug(getClassFuncName(3)+": "+msg);
					CommonClass.logger.debug(msg);
				}
				catch(Exception e){
					bRetry = true;
					continue;
				}
				if(!bRetry)
					return;
				Thread.sleep(500);
			}
			BasePage.sFailMsg = msg +" Element Not Found";
			throw new Exception();
		}
		catch(Exception e){
			CommonClass.logger.debug("Element not found: "+msg);
			throw e;
		}
	}

	public void clickToWindow(WebElement weElement, String msg) throws Exception
	{
		try{
			boolean bRetry;
			for(int i=0; i< 20; i++){
				bRetry = false;
				try{
					if(weElement.isEnabled())
						weElement.click();
					if(!isAlertPresent())
					{
						waitForThread(1000);
						return;
					}
						log.debug(getClassFuncName(3)+": "+msg);
						log.debug(getClassFuncName(1));
				}
				catch(Exception e){
					bRetry = true;
					continue;
				}
				if(!bRetry)
					return;
				Thread.sleep(500);
			}
			throw new Exception();
		}
		catch(Exception e){
			CommonClass.logger.debug("Element not found: "+msg);
			throw e;
		}
	}

	public void selectValue(WebElement selectElement, String sValue, String msg, boolean bWaitForThread) throws Exception
	{
		if(bWaitForThread) waitForThread(CommonClass.iWaitForThread);
		selectValue(selectElement, sValue, msg);
	}

	//to select value from select list
	public void selectValue(WebElement selectElement, String sValue, String msg) throws Exception
	{
		try{
			boolean bRetry;
			for(int i=0; i<5; i++)
			{
				bRetry = false;
				try{
					//					selectElement.sendKeys(Keys.TAB);
					if(selectElement.isEnabled())
						if(!sValue.equalsIgnoreCase("")){
							new Select(selectElement).selectByVisibleText(sValue);
							if(isAlertPresent()){
								try{
									BasePage.sFailMsg= CommonClass.driver.switchTo().alert().getText();
									CommonClass.driver.switchTo().alert().accept();
									log.error("validation fail: "+BasePage.sFailMsg);
									CommonClass.logger.debug("validation fail: "+BasePage.sFailMsg);
									//+ ": [" + msg + "] after step [[" + sGlobalVar + "]]");
								}
								finally{
									if(!bRetry)
										return;
								}}
							log.debug(getClassFuncName(3)+": "+msg+" selected: " + sValue);
							CommonClass.logger.debug(msg+" is " + sValue);
						}}
				catch(Exception e){
					bRetry = true;
					continue;
				}
				if(!bRetry)
					return;	

				Thread.sleep(500);
			}
			BasePage.sFailMsg = msg +" Element Not Found";
			throw new Exception ();
		}
		catch(Exception e){
			CommonClass.logger.debug("Element not found: "+msg);
			throw e;
		}
	}

	public void selectByValue(WebElement selectElement, String sValue, String msg) throws Exception
	{
		try{
			boolean bRetry;
			for(int i=0; i< 20; i++)
			{
				bRetry = false;
				try{
					if(selectElement.isEnabled())
						if(!sValue.equalsIgnoreCase("")){
							//					selectElement.sendKeys(Keys.TAB);
							if(isAlertPresent()){
								try{
									BasePage.sFailMsg= CommonClass.driver.switchTo().alert().getText();
									CommonClass.driver.switchTo().alert().accept();
									log.error("validation fail: "+BasePage.sFailMsg);
									CommonClass.logger.debug("validation fail: "+BasePage.sFailMsg);
								}
								finally{
									if(!bRetry)
										return;
								}}
							new Select(selectElement).selectByValue(sValue);
							log.debug(getClassFuncName(3)+": "+msg+" selected: " + sValue);
							CommonClass.logger.debug(msg+" is " + sValue);
						}}
				catch(Exception e){
					bRetry = true;
					continue;
				}
				if(!bRetry)
					return;

				Thread.sleep(500);
			}
			BasePage.sFailMsg = msg +" Element Not Found";
			throw new Exception ();
		}
		catch(Exception e){
			CommonClass.logger.debug("Element not found: "+msg);
			throw e;
		}
	}

	public void sendValue(WebElement weElement, String sValue, String msg, boolean bWaitForThread) throws Exception
	{
		if(bWaitForThread) waitForThread(CommonClass.iWaitForThread);
		sendValue(weElement, sValue, msg, 4);
	}

	public String getClassFuncName(int iIndex)
	{
		StackTraceElement ste = (Thread.currentThread().getStackTrace())[iIndex];
		return (ste.getClassName() + "." + ste.getMethodName());
	}

	public void sendValue(WebElement weElement, String sValue, String msg) throws Exception
	{
		sendValue(weElement, sValue, msg, 4);
	}

	// to fill value in text field
	public void sendValue(WebElement weElement, String sValue, String msg, int iLevel) throws Exception
	{
		try{
			boolean bRetry;
			for(int i=0; i<6; i++)
			{
				bRetry = false;
				try{
					if(weElement.isEnabled())
						if(!sValue.equalsIgnoreCase("")){
							//						weElement.sendKeys(Keys.TAB);
							if(isAlertPresent()){
								try{
									BasePage.sFailMsg= CommonClass.driver.switchTo().alert().getText();
									CommonClass.driver.switchTo().alert().accept();
									log.error("validation fail: "+BasePage.sFailMsg);
									CommonClass.logger.debug("validation fail: "+BasePage.sFailMsg);
								}
								finally{
									if(!bRetry)
										return;
								}}
							//						weElement.click();
							weElement.clear();
							weElement.sendKeys(sValue);
							log.debug(getClassFuncName(iLevel) + ":" + msg + ":" + sValue);
							CommonClass.logger.debug(msg+" is " + sValue);
						}
						else if(sValue.equalsIgnoreCase(""))
							log.debug(msg+" no value to be filled for this field");
				}
				catch(Exception e){
					bRetry = true;
					continue;
				}
				if(!bRetry)
					return;
				Thread.sleep(300);
			}
			BasePage.sFailMsg = msg +" Element Not Found";
			throw new Exception ();
		}
		catch(Exception e){
			CommonClass.logger.debug("Element not found: "+msg);
			throw e;
		}
	}

	public void clicksendValue(WebElement weElement, String sValue, String msg) throws Exception
	{
		try{
			boolean bRetry;
			for(int i=0; i< 5; i++)
//				for(int i=0; i< 20; i++)
			{
				bRetry = false;
				try{
					if(weElement.isEnabled())
						if(!sValue.equalsIgnoreCase("")){
							//						weElement.sendKeys(Keys.TAB);
							if(isAlertPresent()){
								try{
									BasePage.sFailMsg= CommonClass.driver.switchTo().alert().getText();
									CommonClass.driver.switchTo().alert().accept();
									log.error("validation fail: "+BasePage.sFailMsg);
									CommonClass.logger.debug("validation fail: "+BasePage.sFailMsg);
								}
								finally{
									if(!bRetry)
										return;
								}}
							//						weElement.click();
							weElement.click();
							weElement.sendKeys(sValue);
							log.debug(getClassFuncName(4) + ":" + msg + ":" + sValue);
							CommonClass.logger.debug(msg+" is " + sValue);
						}
						else if(sValue.equalsIgnoreCase(""))
							log.debug(msg+" no value to be filled for this field");
				}
				catch(Exception e){
					bRetry = true;
					continue;
				}
				if(!bRetry)
					return;
				Thread.sleep(300);
			}
			BasePage.sFailMsg = msg +" Element Not Found";
			throw new Exception ();
		}
		catch(Exception e){
			CommonClass.logger.debug("Element not found: "+msg);
			throw e;
		}
	}

	public void sendValue(WebElement weElement, String sValue) throws Exception
	{
		sendValue(weElement, sValue, "Value", 4);
	}

	public void waitForElementToBeClickable(WebElement weElement) throws Exception
	{
		try
		{	
			CommonClass.wait.until(ExpectedConditions.elementToBeClickable(weElement));
		}
		catch (StaleElementReferenceException e) 
		{
			CommonClass.action.moveToElement(weElement).build().perform();
			CommonClass.wait.until(ExpectedConditions.elementToBeClickable(weElement));
			log.error("Stale Exception: Retrying...");
		}
		catch (NoSuchElementException e) 
		{
			CommonClass.action.moveToElement(weElement).build().perform();
			CommonClass.wait.until(ExpectedConditions.elementToBeClickable(weElement));
			log.error("Stale Exception: Retrying...");
		}
		catch(Exception e)
		{
			log.error("Exception: ");
		}
	}

	public static String getStackTrace(Throwable throwable)
	{
		String sMsg = "";
		Writer writer = new StringWriter();
		PrintWriter printWriter = new PrintWriter(writer);
		try
		{
			throwable.printStackTrace(printWriter);
			printWriter.flush();
			writer.flush();
			sMsg = writer.toString();
			writer.close();
			printWriter.close();
		}
		catch(Exception e) {}   //Ignore error

		return sMsg;
	}

	public void waitElement(WebElement weElement, String msg) throws Exception {
		waitElement(weElement);
		log.debug(getClassFuncName(4)+"Click on: "+msg);
	}

	public void waitElement(WebElement weElement) throws Exception {
		boolean bRetry;
		for(int i=0; i< 20; i++)
		{
			bRetry = false;
			try{
				weElement.click();
			}
			catch(Exception e){
				bRetry = true;
				continue;
			}
			if(!bRetry)
				return;

			Thread.sleep(500);
		}
		throw new Exception ("Element not found: "+ weElement);
	}


	public void switchFrame(WebElement weElement) throws Exception {
		try{
			boolean bRetry;
			for(int i=0; i< 8; i++)
			{
				bRetry = false;
				try{
					CommonClass.driver.switchTo().frame(weElement);
				}
				catch(NoSuchElementException e){
					bRetry = true;
					continue;
				}
				if(!bRetry)
					return;

				Thread.sleep(500);
			}
			throw new Exception ("Element not found: "+ weElement);
		}
		catch(Exception e){
			CommonClass.logger.debug("Frame is not found.");
			throw e;
		}
	}
	public void fnWaitFrame(WebElement weFrmae, WebElement weElement, String sMsg) throws Exception {
		waitForThread(2000);
		CommonClass.driver.switchTo().defaultContent();
		waitForThread(1000);
		switchFrame(weFrmae);
		waitForThread(1000);
		CommonClass.action.moveToElement(weElement).build().perform();
		clickElement(weElement, sMsg);
	}
	public void switchwindow() throws Exception {
		try {
			for (String handle : CommonClass.driver.getWindowHandles()) {
//				System.out.println("@@@@ Switch Window Msg ==" + handle);
				driver.switchTo().window(handle);
			}
		} catch (Exception e) {
			CommonClass.logger.debug("Window is not found.");
			throw e;
		}
	} 
	
	public static void fnWaitPage(int iCount) {
		try {
			for(int i=0; i<iCount; i++) {
				Thread.sleep(500);
			}
		}
		catch (Exception e) {}
	}
	
	public static void fnTabElement(WebElement weElement, int iCount) {
		try {
			for(int i=0; i<iCount; i++) {
				weElement.sendKeys(Keys.TAB);
				Thread.sleep(500);
			}
		}
		catch (Exception e) {}
	}
	
	public void closePopup(WebElement weElement, String msg) throws Exception {
		try{
			boolean bRetry;
			Report.sFailMsg = msg+" Element not found";
			for(int i=0; i<5; i++){
				bRetry = false;
				waitForThread(2000);
				try{
					weElement.click();
					if(isAlertPresent()){
						try{
							Report.sFailMsg= CommonClass.driver.switchTo().alert().getText();
							CommonClass.driver.switchTo().alert().accept();
							log.error("validation fail: "+BasePage.sFailMsg);
							Report.fnExtentDebugger(false, "validation");
						}
						catch(Exception e){getStackTrace(e);}
						finally{
							if(!bRetry)
								return;
						}}
					log.debug(getClassFuncName(3)+": "+msg);
				}
				catch(Exception e){
					bRetry = true;
					continue;
				}
				if(!bRetry)
					return;
				Thread.sleep(500);
			}
			throw new Exception();
		}
		catch(Exception e){
			//			CommonClass.logger.debug("Element not found: "+msg);
			Report.fnExtentDebugger(false);
			throw e;
		}
	}
	
	public void jsClick(WebElement element) throws Exception {
		try {
			if (element.isEnabled() && element.isDisplayed()) {
				System.out.println("Clicking on element with using java script click");

				((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
			} else {
				System.out.println("Unable to click on element");
			}
		} catch (StaleElementReferenceException e) {
			System.out.println("Element is not attached to the page document "+ e.getStackTrace());
		} catch (NoSuchElementException e) {
			System.out.println("Element was not found in DOM "+ e.getStackTrace());
		} catch (Exception e) {
			System.out.println("Unable to click on element "+ e.getStackTrace());
		}
	}
	
	public void jsScroll(int a ,int b)throws Exception {
		try {
			
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(a,b)");
			
		} catch (Exception e) {
		
		}
	}
	
	
	
}






