package lib;

import java.io.File;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.WebDriverWait;
//import org.sikuli.script.Screen;
import org.testng.ITestContext;
import org.testng.TestRunner;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;

import Pages.BasePage;

public class CommonClass
{
	
	public static  String Login ;
//	public static  String HomePage;

	public static WebDriver driver;
	public static Actions action;
	public static WebDriverWait wait;
	public static WebDriverWait wait1;
	public static Alert alert;
//	public static Screen sc;
	
	
	public static StringBuffer verificationErrors = new StringBuffer();
	private static Timestamp ts = new Timestamp(System.currentTimeMillis());
    private static String sImgCounter = Long.toString(ts.getTime());
    private static int iImgCounter = Integer.parseInt(sImgCounter.substring(sImgCounter.length()-8, sImgCounter.length()));
	public static Logger log = LogManager.getLogger(CommonClass.class);

	//Globals variables defined here --- START ---
	// Wait for long duration
	public static int iWaitForElement;
	public static int iWaitForThread;
	public static int iWaitForThread2;
	public static int iWaitForThread1;
	// Globals
	public static String BROWSER;
	public static String CHROME_DRIVER_PATH;
	public static String IE_DRIVER_PATH;
	public static String OUTPUT_PATH;
	public static String IMAGES_PATH;
	public static String Wish_Data;
	public static String SHEET1;
	public static String SHEET2;
	public static String SHEET3;
	public static String SHEET4;
	public static String SHEET5;
	public static String SHEET6;
	public static String SHEET7;
	public static boolean bRunInTestMode = false;
	public static boolean bPrintScreen = false;  
	public static int TESTCASES;
	public static String sBaseURL;

	//Globals variables defined here ---  END  ---
	public static ExtentHtmlReporter htmlReporter;
	public static ExtentReports extent;
	public static ExtentTest logger;

	@BeforeSuite
	@Parameters({"bRunInTestMode", "bPrintScreen",
		"CHROME_DRIVER_PATH","IE_DRIVER_PATH","OUTPUT_PATH","IMAGES_PATH",
		"iWaitForElement","iWaitForThread","iWaitForThread1","iWaitForThread2","sBaseURL"})
	public void setup(ITestContext ctx, Boolean bRunInTestMode, Boolean bPrintScreen,
			String CHROME_DRIVER_PATH, String IE_DRIVER_PATH, String OUTPUT_PATH, String IMAGES_PATH,
			int iWaitForElement, int iWaitForThread, int iWaitForThread1, int iWaitForThread2, String sBaseURL)
	{
		DOMConfigurator.configure("log4j.xml");
		log.info("Before suite launch...");
		TestRunner runner = (TestRunner) ctx;

		OUTPUT_PATH = (new File(runner.getOutputDirectory())).getParent();
		IMAGES_PATH = new File(runner.getOutputDirectory()).getParent() + "_Images\\";

		//Globals variables populated here --- START ---
		CommonClass.bRunInTestMode 		= bRunInTestMode;
		CommonClass.bPrintScreen 		= bPrintScreen;
		CommonClass.CHROME_DRIVER_PATH	= CHROME_DRIVER_PATH;
		CommonClass.IE_DRIVER_PATH 		= IE_DRIVER_PATH;
		CommonClass.OUTPUT_PATH 		= OUTPUT_PATH;
		CommonClass.IMAGES_PATH 		= IMAGES_PATH;
		CommonClass.iWaitForElement 	= iWaitForElement;
		CommonClass.iWaitForThread 		= iWaitForThread;
		CommonClass.iWaitForThread1 	= iWaitForThread1;
		CommonClass.iWaitForThread2 	= iWaitForThread2;
		CommonClass.sBaseURL			= sBaseURL;
		CommonClass.Wish_Data			= BasePage.sDataPath;
		//Globals variables populated here ---  END  ---

		//Globals variables dumped here --- START ---
		log.debug("CHROME_DRIVER_PATH:" + CHROME_DRIVER_PATH);
		log.debug("IE_DRIVER_PATH:" + IE_DRIVER_PATH);
		log.debug("Output Folder:" + OUTPUT_PATH);
		log.debug("Images Folder:" + IMAGES_PATH);
		//Globals variables dumped here ---  END  ---
	}

	@BeforeTest
	@Parameters({"browser","SHEET1","SHEET2", "SHEET3","TESTCASES"})
	public void setUp(String browser, String SHEET1, String SHEET2, String SHEET3, int TESTCASES) throws Exception
	{
		log.info("Before test launch...");
		log.debug("Testing on browser: " + browser);
		fnDate1();
		browser = browser.toLowerCase();
		if (browser.equals("chrome"))
		{    
			System.setProperty("webdriver.chrome.driver", "Library\\chromedriver.exe");
			driver = new ChromeDriver();
		}
		else if (browser.equals("firefox"))
		{
			System.setProperty("webdriver.geckodriver", " ");
			driver = new FirefoxDriver();
		}
		else if (browser.equals("ie"))
		{
			DesiredCapabilities capability = DesiredCapabilities.internetExplorer();
			capability.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
			capability.setCapability(InternetExplorerDriver.ELEMENT_SCROLL_BEHAVIOR, 1); 
			capability.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			capability.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);        
			capability.setJavascriptEnabled(true);
			System.setProperty("webdriver.ie.driver", IE_DRIVER_PATH);
			driver = new InternetExplorerDriver(capability);
		}
		else{
			throw new RuntimeException("No driver available for browser: " + browser);
		}

		CommonClass.BROWSER = browser; 
		CommonClass.SHEET1 = SHEET1;
		CommonClass.SHEET2 = SHEET2;
		CommonClass.SHEET3 = SHEET3;
		
		CommonClass.TESTCASES = TESTCASES;
		action = new Actions(driver);
		wait = new WebDriverWait(driver, 10);

		driver.manage().window().maximize(); // To Maximize Window	  
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
//		CommonClass.htmlReporter = new ExtentHtmlReporter(new File("Result//WishReport.html"));
		CommonClass.htmlReporter = new ExtentHtmlReporter(new File("Result//term-WishReport"+CommonClass.sDate+".html"));
		CommonClass.extent = new ExtentReports ();
		CommonClass.extent.attachReporter(CommonClass.htmlReporter);
		CommonClass.extent.setSystemInfo("Host Name", "Winfish insurance");
		CommonClass.extent.setSystemInfo("Environment", "Automation Testing");
		CommonClass.extent.setSystemInfo("User Name", "Rahul ");
		CommonClass.htmlReporter.config().setDocumentTitle("Wish Report");
		CommonClass.htmlReporter.config().setReportName("Wish ");
		CommonClass.htmlReporter.config().setTestViewChartLocation(ChartLocation.TOP);
		CommonClass.htmlReporter.config().setTheme(Theme.STANDARD);
//		CommonClass.sc = new Screen();
		log.info("Before test ended..");
	}
	@AfterTest
	public void tearDown() throws Exception
	{
		// WebDriver will be closed
		Thread.sleep(5000);
		log.info("Starting tear Down");
				driver.quit();
		CommonClass.extent.flush();
		Thread.sleep(5000);
		Thread.sleep(2000);
		Report.attachedMail(BasePage.EmailCC1, BasePage.EmailCC2,"ayush.srivastava@wishfin.com", "Rahul", BasePage.EmailSendto, "term-verify premium Report", "Term Automation Report",
				"Result//term-WishReport"+CommonClass.sDate+".html", "term-Autmation Report.html");
		
	}
	
	public static int getNextImgCounter()
	{
		iImgCounter++;
		return iImgCounter;
	}
	static String sDate = "";
	public static void fnDate1() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd hh-mm-ss");
		LocalDateTime now = LocalDateTime.now();
		sDate = dtf.format(now);
	}

	public static FirefoxProfile downloadPDFFile()
	{
		FirefoxProfile profile=new FirefoxProfile();
		profile.setPreference("browser.download.folderList", 2);
		profile.setPreference("pdfjs.disabled", true);
		profile.setPreference("browser.helperApps.neverAsk.saveToDisk","application/pdf");
		return profile;
	}
}
