package lib;

import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;

public class Data {

	public static String sProductValue;
	public int iTestCaseID;
	//HomePage page
	public String sLoginID, sURL;
	
	// Page1
	public static List<String> sPage1 ,sMemberId,sPolicy_ID, sGender,sAge,sSmoker,   sPolicyCompany, sMemName,sMemPhone,sMemEmail,
	 sPolicyInstallment , sSumInsuredAmount ,SPolicyTerm , sExpPremAmt;
	
	// get data Login
	public static Object[][] getData1(Sheet sheet, int iCount) throws Exception {
		Object[][] vedData1 = new Object[iCount][2];
		Data plan1 = null;

		for (int i = 0; i < iCount; i++) {
			plan1 = new Data();

			Row iRow = sheet.getRow(i + 2);
			plan1.iTestCaseID = i + 1;

			plan1.sLoginID			=CommonExcel.getExcelCellValue(iRow,0);
			plan1.sURL				=CommonExcel.getExcelCellValue(iRow,1);

			vedData1[i][0] = plan1.iTestCaseID;
			vedData1[i][1] = plan1;
		}
		return vedData1;
	}

	//  Page1
	public static Object[][] getData2(Sheet sheet, int iCount) throws Exception {
		Object[][] vedData1 = new Object[iCount][2];
		Data plan1 = null;
		
		sMemberId = new ArrayList<String>();
		sPolicy_ID = new ArrayList<String>();
		sGender = new ArrayList<String>();
		sAge = new ArrayList<String>();          
		sSmoker = new ArrayList<String>();
		sPolicyCompany = new ArrayList<String>();
		sMemName = new ArrayList<String>();
		sMemPhone = new ArrayList<String>();
		sMemEmail = new ArrayList<String>();
		sPolicyInstallment = new ArrayList<String>();
		sSumInsuredAmount = new ArrayList<String>();
		SPolicyTerm = new ArrayList<String>();
		sExpPremAmt = new ArrayList<String>();
		

		for (int i = 0; i < iCount; i++) {
			plan1 = new Data();

			Row iRow = sheet.getRow(i + 2);
			plan1.iTestCaseID = i + 1;
			
			
			sMemberId.add(i, CommonExcel.getExcelCellValue(iRow,0));
			sPolicy_ID.add(i, CommonExcel.getExcelCellValue(iRow,1));
			sGender.add(i, CommonExcel.getExcelCellValue(iRow,2));
			sAge.add(i, CommonExcel.getExcelCellValue(iRow,3));
			sSmoker.add(i, CommonExcel.getExcelCellValue(iRow,4));
			sPolicyCompany.add(i, CommonExcel.getExcelCellValue(iRow,5));
			sMemName.add(i, CommonExcel.getExcelCellValue(iRow,6));
			sMemPhone.add(i, CommonExcel.getExcelCellValue(iRow,7));
			sMemEmail.add(i, CommonExcel.getExcelCellValue(iRow,8));
			sPolicyInstallment.add(i, CommonExcel.getExcelCellValue(iRow,9));
			sSumInsuredAmount.add(i, CommonExcel.getExcelCellValue(iRow,10));
			SPolicyTerm.add(i, CommonExcel.getExcelCellValue(iRow,11));
			sExpPremAmt.add(i, CommonExcel.getExcelCellValue(iRow,12));


			vedData1[i][0] = plan1.iTestCaseID;
			vedData1[i][1] = plan1;
		}
		return vedData1;
	}
	//   Page 2
	public static Object[][] getData3(Sheet sheet, int iCount) throws Exception {
		Object[][] vedData1 = new Object[iCount][1];
		Data plan1 = null;
		

		for (int i = 0; i < iCount; i++) {
			plan1 = new Data();

			Row iRow = sheet.getRow(i + 2);
			plan1.iTestCaseID = i + 1;
			


			vedData1[i][0] = plan1.iTestCaseID;
			vedData1[i][0] = plan1;
		}
		return vedData1;
	}

	//  Page 3 
	public static Object[][] getData4(Sheet sheet, int iCount) throws Exception {
		Object[][] vedData1 = new Object[iCount][2];
		Data plan1 = null;


		
		for (int i = 0; i < iCount; i++) {
			plan1 = new Data();

			Row iRow = sheet.getRow(i + 2);
			plan1.iTestCaseID = i + 1;
			


			vedData1[i][0] = plan1.iTestCaseID;
			vedData1[i][1] = plan1;
		}
		return vedData1;
	}

	
}