package lib;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.testng.annotations.DataProvider;



public class CommonExcel
{
	Data testData;
	public static Logger log = LogManager.getLogger(CommonExcel.class);
	
	

	@DataProvider(name="getdata1")
	public static Object[][] getData1() throws Exception
	{
		Object [][] vedData = null;
		int iCount =0;
		FileInputStream fis=null;
		try
		{
			fis = new FileInputStream(CommonClass.App_Data);
			Workbook wb= WorkbookFactory.create(fis);
			Sheet sheet = wb.getSheet(CommonClass.SHEET1);
			iCount = CommonClass.TESTCASES;
			vedData = new Object[iCount][2];
			vedData = Data.getData1(sheet, iCount);
		}
		catch(Exception ex)
		{
			log.error("Exception:" + ex.getMessage());
			log.error(BaseClass.getStackTrace(ex));
		}
		finally
		{
			if(fis != null)
			{
				try { fis.close(); }
				catch(Exception ex){}
			}
		}
		return vedData;
	}

	public static Object[][] getData2() throws Exception
	{
		Object [][] vedData = null;
		FileInputStream fis=null;
		try
		{
			fis = new FileInputStream(CommonClass.App_Data);
			
			Workbook wb= WorkbookFactory.create(fis);
			Sheet sheet = wb.getSheet(CommonClass.SHEET2);

			int iCount = sheet.getLastRowNum();
			vedData = new Object[iCount][2];
			vedData = Data.getData2(sheet, iCount);
		}
		catch(Exception ex)
		{
			log.error("Exception:" + ex.getMessage());
			log.error(BaseClass.getStackTrace(ex));
		}
		finally
		{
			if(fis != null)
			{
				try { fis.close(); }
				catch(Exception ex){}
			}
		}
		return vedData;
	}

	public static Object[][] getData3() throws Exception
	{
		Object [][] vedData = null;
		FileInputStream fis=null;
		try
		{
			fis = new FileInputStream(CommonClass.App_Data);
			Workbook wb= WorkbookFactory.create(fis);
			Sheet sheet = wb.getSheet(CommonClass.SHEET3);

			int iCount = sheet.getLastRowNum();
			vedData = new Object[iCount][2];
			vedData = Data.getData3(sheet, iCount);
		}
		catch(Exception ex)
		{
			log.error("Exception:" + ex.getMessage());
			log.error(BaseClass.getStackTrace(ex));
		}
		finally
		{
			if(fis != null)
			{
				try { fis.close(); }
				catch(Exception ex){}
			}
		}
		return vedData;
	}

	
	@SuppressWarnings({"resource"})
	public static void setData(int iRow, String sTest, String sRes) throws Exception
	{
		try{
			FileInputStream fsIP= new FileInputStream(new File("Results.xls"));  
			HSSFWorkbook wb = new HSSFWorkbook(fsIP);
			HSSFSheet worksheet = wb.getSheetAt(0); 
			Row row = null;
			for(int i=0; i<100; i++){
				row = worksheet.getRow(iRow);
				if(row==null){
					row = worksheet.createRow(iRow);
					row.createCell(0).setCellValue(sTest);
					row.createCell(1).setCellValue(sRes);
					break;
				}
				else
				{
					iRow++;
				}
			}
			fsIP.close(); 
			FileOutputStream output_file =new FileOutputStream(new File("Results.xls"));  
			wb.write(output_file);
			output_file.close();}
		catch(Exception e){
			log.error(BaseClass.getStackTrace(e));

		}
	}

	public static String getExcelCellValue(Row row, int iCell)
	{
		String sRetValue = "";
		try
		{
			if(row.getCell(iCell).getCellTypeEnum()==CellType.STRING)
				sRetValue = row.getCell(iCell).getStringCellValue().trim();
			else
				sRetValue = String.valueOf((long)row.getCell(iCell).getNumericCellValue()).trim();
		}
		catch(NullPointerException ex) {}

		return sRetValue;
	}
}
