package Tests;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.TestNG;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;

import Pages.BasePage;

public class TestStart {

	public static void main(String[] args) {
		BasePage.fnConfig();
		XmlSuite suite = new XmlSuite();
		suite.setName("TmpSuite");
		Map<String, String> mSuite = new HashMap<String, String>();
		mSuite.put("bRunInTestMode", "true");
		mSuite.put("bPrintScreen", "true");
		mSuite.put("CHROME_DRIVER_PATH", "");
		mSuite.put("OUTPUT_PATH", "");
		mSuite.put("IMAGES_PATH", "");
		mSuite.put("iWaitForElement", "20");
		mSuite.put("iWaitForThread", "1000");
		mSuite.put("iWaitForThread1", "2000");
		mSuite.put("iWaitForThread2", "4000");
		mSuite.put("sBaseURL", BasePage.App_URL);
		suite.setParameters(mSuite);

		XmlTest test = new XmlTest(suite);
		test.setName("TmpTest");
		Map<String, String> mTest = new HashMap<String, String>();
		mTest.put("browser", "chrome");
		mTest.put("SHEET1", "Enter your sheet1  Name");
		mTest.put("SHEET2", "Enter your sheet2  Name");
		mTest.put("SHEET3", "Enter your sheet3  Name");
		
		mTest.put("TESTCASES", "1");
		
		test.setParameters(mTest);
		List<XmlClass> classes = new ArrayList<XmlClass>();
		classes.add(new XmlClass("lib.CommonClass"));
		classes.add(new XmlClass("Tests.CreatePolicyTest"));
		
		
		test.setXmlClasses(classes) ;

		List<XmlSuite> suites = new ArrayList<XmlSuite>();
		suites.add(suite);
		TestNG tng = new TestNG();
		tng.setXmlSuites(suites);
		tng.run();
	}
}
