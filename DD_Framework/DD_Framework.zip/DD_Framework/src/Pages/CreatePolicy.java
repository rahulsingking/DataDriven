package Pages;

import java.util.List;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import lib.Data;
import lib.Report;

public class CreatePolicy extends BasePage {

	public static Logger log = LogManager.getLogger(CreatePolicy.class);

	public CreatePolicy() {
		super();
	}
//	@FindBy(xpath = "(//span[contains(text(),'MALE')])[1]")
	@FindBy(xpath = "//div[@class='user-img'][1]")
	WebElement weGenderMale;
	@FindBy(xpath = "//span[contains(text(),'FEMALE')]")
	WebElement weGenderFemale;
	

	public void fnGenderSelect(int iRow) throws Exception {
		try {
			BasePage.sTestStep = "Select Page";
			if (Data.sGender.get(iRow).equalsIgnoreCase("Female")) {
				clickElement(weGenderFemale, "SelectGender:: Female");
			} else if (Data.sGender.get(iRow).equalsIgnoreCase("Male")) {
				clickElement(weGenderMale, "SelectGender:: Male");
			}
		} catch (Exception e) {
			Report.TestReport("Wish Gender Select", "WIsh Gender Select Fail for ", Data.sPolicy_ID.get(iRow), "Fail");
			System.out.println(getStackTrace(e));
			throw e;
		}
	}
	
}