package Pages;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class CreateUploadFile {

		private static Logger log = LogManager.getLogger(CreateUploadFile.class);

	private static FileOutputStream fos;
	private static BufferedWriter bw;
	
	public static boolean sFlag = true;
	
	public static void fnCleanFile() throws Exception {
		File fout = new File("Data_Premium\\GetPremium.csv");
		fos = new FileOutputStream(fout, false);
	}
	
	public static void fnCreateFile() throws Exception {
		File fout = new File("Data_Premium\\GetPremium.csv");
		fos = new FileOutputStream(fout, true);
		bw = new BufferedWriter(new OutputStreamWriter(fos));
		if(sFlag)
		{
			fnFirstLine();
			sFlag = false;
		}
	}
	static String sDate = "";
	public static void fnDate1() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd hh-mm-ss");
		LocalDateTime now = LocalDateTime.now();
		sDate = dtf.format(now);
	}

	private static void fnFirstLine() throws Exception {
		bw.write("Policy_ID");
		bw.write(", ");
		bw.write("Age");
		bw.write(", ");
		bw.write("Gender");
		bw.write(", ");
		bw.write("Smoker");
		bw.write(", ");
		bw.write("Policy_Company");
		bw.write(", ");
		bw.write("Policy Installment");
		bw.write(", ");
		bw.write("Plan_Amount");
		bw.write(", ");
		bw.write("Term_Year");
		bw.write(", ");
		bw.write("Epected Premium Ammount");
		bw.write(", ");
		bw.write("Actual Premium Ammount");
		bw.write(", ");
		bw.write("Status");
		bw.write(", ");
		bw.write("Diff Of Premium");
		bw.write(", ");
	}

	public static void fnUpdateCSV(String str, boolean bLine) throws Exception {
		try{
			fnCreateFile();
			if(bLine)
				bw.newLine();
			bw.write(str);
			bw.write(", ");
		}
		catch(Exception e){
			//			log.error("Unable to update Test result in file.");
		}
		finally{
			if(bw!=null)
				bw.close();
		}
	}
	
}
